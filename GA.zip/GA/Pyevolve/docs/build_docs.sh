#!/bin/sh
sphinx-build -E -a -b html ./source ./build

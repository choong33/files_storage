
Contributors
==============================================

**Boris Gorelik**, from `Procognia Ltd <http://procognia.com>`_, `Blog inthehaystack.com <http://www.inthehaystack.com/>`_, `@boris_gorelik <http://twitter.com/boris_gorelik>`_, Ashdod, Israel.

.. image:: imgs/email_boris.png

**Amit Saha**, `Blog amitksaha.wordpress.com <http://amitksaha.wordpress.com/>`_, `@amitsaha <http://twitter.com/amitsaha>`_, India.

.. image:: imgs/email_amit.png

**Jelle Feringa**, Jelle Feringa, Tu Delft University, Netherlands.

.. image:: imgs/email_jelle.png

**Henrik Rudstrom**, `Blog uniqueidentifier.net <http://uniqueidentifier.net>`_, `@henrk <http://twitter.com/henrk>`_, Rotterdam, Netherlands.

.. image:: imgs/email_henrik.png

**Christian Kastner**, Austria.

.. image:: imgs/email_christian_kastner.png

**Eric Floehr**, `Intellovations <http://www.intellovations.com/>`_, `@ForecastWatch <http://twitter.com/ForecastWatch>`_, Ohio, USA.

.. image:: imgs/email_eric_floehr.png

**Lorenzo Riano**, from `ISRC, University of Ulster <http://isrc.ulster.ac.uk/Staff/LRiano/Contact.html>`_, `@lorenzoriano <https://twitter.com/lorenzoriano>`_, UK.

**Blaine Booher**, `University of Cincinnati, Cincinnati, Ohio USA`_,

.. image:: imgs/email_blaine.png

**Lebedev Ilya**, `@melevir <http://twitter.com/melevir>`_, Moscow, Russia.

.. image:: imgs/email_melevir.png


Contact the author
====================================

If you have any questions or suggestions, you can contact me at:

christian.perone@gmail.com

.. image:: imgs/brasil_flag.jpg


Please use the word "pyevolve" in the email subject.


Donate
====================================

Please, `donate <http://sourceforge.net/donate/index.php?group_id=251160>`_ to support the development of this project.

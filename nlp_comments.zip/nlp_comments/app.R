#https://github.com/datastorm-open/visNetwork/issues/168

library(shiny)
library(tm)
library(networkD3)
library(visNetwork)
library(data.tree)
library("SnowballC")  
library("wordcloud")
library("RColorBrewer")
#library(plotly)
library(dplyr)
#library(udpipe)
library(igraph)

# TASKS TO COMPLETE
#Select ILIW (slice into 4 quarters)
#Write logic which quarter file to choose (input from dropdown menu. )
#Separate the comments into like and wish 
#Run udpipe and get the cooc and save to network_graph.csv (like and wish)
#Get the shortest path and save accordingly to wordlike.csv and wordwish.csv)

dflike <- read.csv('wordlike.csv',header=T,stringsAsFactors = F)
dflike <- dflike[dflike$a != 'wish',]
word_freq_like <- sort(table(dflike$a),decreasing=T)
wordlike <- names(word_freq_like)
wordss <- wordlike

dfSearch <- read.csv('ILIW.CSV',header=T,stringsAsFactors = F)
col <- c("Date", "Email.Address","User.ID","Completion")
dfSearch$Date <- as.Date(dfSearch$Date)

#### Server ####
server <- function(input, output,session) {
  
  # For wordcloud
  word = reactive({
    dflike <- read.csv('wordlike.csv',header=T,stringsAsFactors = F)
    dflike <- dflike[dflike$a != 'wish',]
    docs <- VCorpus(VectorSource(dflike))
    dtm <- TermDocumentMatrix(docs)
    m <- as.matrix(dtm)
    v = sort(rowSums(m),decreasing = TRUE)
    data.frame(word=names(v),freq=v)$word
  })
  
  freq = reactive({
    dflike <- read.csv('wordlike.csv',header=T,stringsAsFactors = F)
    dflike <- dflike[dflike$a != 'wish',]
    docs <- VCorpus(VectorSource(dflike))
    dtm <- TermDocumentMatrix(docs)
    m = as.matrix(dtm)
    v = sort(rowSums(m),decreasing = TRUE)
    data.frame(word=names(v),freq=v)$freq
  })

 # For network graph
 net1 = reactive({
   dfnet <- read.csv('network_graph.csv',header=T,stringsAsFactors = F)
   n <- nrow(dfnet)
   level1 <- as.integer(0.3*n)
   level2 <- as.integer(0.6*n)
   level3 <- n
   updateSelectInput(session, "levels",
                     choices = c("Level 1","Level 2", "Level 3"),
                     selected=input$levels)
   if(input$levels=="Level 1"){dfnet <- dfnet[1:level1,]}
   else if(input$levels=="Level 2"){dfnet <- dfnet[1:level2,]}
   else if(input$levels=="Level 3"){dfnet <- dfnet[1:n,]}
 })
  
 # For search details 
  searchfunc <- reactive({
    dfSearch <- read.csv('ILIW.CSV',header=T,stringsAsFactors = F)
    col <- c("Date", "Email.Address","User.ID","Completion")
    dfSearch$Date <- as.Date(dfSearch$Date)
    dfSearch <- dfSearch[,col]
    startdate <- input$daterange[1]
    enddate <- input$daterange[2]
    #with(dfSearch, dfSearch[Date >= startdate & Date <= enddate, ])
    dfSearch <- dfSearch[dfSearch$Date >= as.character(startdate) & dfSearch$Date <= as.character(enddate),]
    dfSearch <- dfSearch[,col]
    dfSearch$Date <- as.character(dfSearch$Date)
    searchwords <- c(input$words,input$search) # the search term
    
    search1 <- input$words  # first branch of search details
    search2 <- input$search # second branch of search details
    #search3 <- paste("^",search2,"$")
    result1 <- dfSearch[ grep(search1, dfSearch$Completion) , ]  #slice by first branch
    result <- result1[grep(search2, result1$Completion), ]
    
  })
  
  # For diagonal network
  diagonal <- reactive({
    
    if (input$wishlike == "Like"){
      df <- read.csv('wordlike.csv',header=T,stringsAsFactors = F)
      df <- df[df$a != 'wish',]
      word_freq_like <- sort(table(df$a),decreasing=T)
      wordlike <- names(word_freq_like)
      wordss <- wordlike
      if (input$words %in% wordss) { 
         updateSelectInput(session, "words",
                          choices = wordss,
                          selected=input$words)
         word2 <- input$words                
                                    } 
      else {
         updateSelectInput(session, "words",
                          choices = wordss)
         word2 <- wordss[2]  #the word in the main branch of diagonal network. Ex: video,digital  
           }
      
      df1 <- df[df$a==word2,]
      df1$pathString <- paste("LIKE",df1$a,df1$b,df1$c,df1$d,df1$e,df1$f, sep= "|")
      
    }
    else if (input$wishlike == "Wish") {
      df <- read.csv('wordwish.csv',header=T,stringsAsFactors = F)
      word_freq_wish <- sort(table(df$a),decreasing=T)
      wordwish <- names(word_freq_wish)
      wordss <- wordwish
      if (input$words %in% wordss) { 
      updateSelectInput(session, "words",
                        choices = wordss,
                        selected=input$words)
       word2 <- input$words                
      } 
      else {
        updateSelectInput(session, "words",
                          choices = wordss)
                          #selected=input$words)
      word2 <- wordss[2] #the word in the main branch of diagonal network. Ex: video,digital    
            } 
      
      df1 <- df[df$a==word2,]
      
      # X2 = a, X3 = b, X4 = c , and so on
      df1$pathString <- paste("WISH",df1$a,df1$b,df1$c,df1$d,df1$e,df1$f, sep= "|")
    }
    
    #searchword1 <- unique(df1[c("b", "c")])
    updateSelectInput(session, "search",
                      choices = unique(df1$b),
                      #selected=input$search)
                      selected=unique(df1$b)[5])

    wordTree <- as.Node(df1, pathDelimiter = "|")
    wordTreeList <- ToListExplicit(wordTree, unname =TRUE)
    
  })
  
## START OUTPUT MODULE#######################################################################
########################################################################################
  
  # Ouput for diagonal network
  output$diag <- renderDiagonalNetwork({diagonalNetwork(List=diagonal(), 
                                                        fontSize = 9, 
                                                        fontFamily = "OpenSans-Light", 
                                                        nodeStroke = "orange",
                                                        linkColour = "#AAA",
                                                        opacity = 0.9)#input$opaci)
  })
  
  # Output for wordcloud
  output$wordcloud <- renderPlot({
    wordcloud(words = word(), 
              freq = freq(), 
              min.freq = 1, scale = c(8,0.8),
              max.words=input$max, random.order=FALSE, rot.per=0.35, 
              colors=brewer.pal(8, "Dark2"))
  })
  
  output$wordplot <- renderPlot({ 
     numwords = as.integer(input$max/2)
     barplot(freq()[1:numwords], las = 2, names.arg = word()[1:numwords],
             col ="gold", main ="Most frequent words",
             ylab = "Word frequencies")
  })
  
  # Output for search details
  output$search <- renderTable(searchfunc())
  
  # Output for network graph
  output$network <- renderVisNetwork({
    dfnet <- net1()
    weight <- dfnet$cooc
    
    nodes <- data.frame(id =unique(dfnet$term1),label = unique(dfnet$term1),
                        value=length(unique(dfnet$term1)):1,group = unique(dfnet$term1),#shape="circle",
                        #title = paste0("<p>", unique(dfnet$term1),"<br> !</p>"), stringsAsFactors = FALSE)
                        title = paste0("<p>", unique(dfnet$term1)), stringsAsFactors = FALSE)
    #edges <- data.frame(from = dfnet$term1, to = dfnet$term2)
    edges <- data.frame(from = dfnet$term1, to = dfnet$term2)
    edges <- mutate(edges, width = weight/5 + 1)
    
    visNetwork(nodes, edges, height = "750px", width = "100%") %>% 
    visNodes(scaling = list(label = list(enabled = T))) %>%
    visGroups(groupname = "like", color = "blue", shape = "triangle", size=45) %>%
                #shadow = list(enabled = TRUE)) %>% 
      #visGroups(groupname = "like", shape = "icon", icon = list(code = "f164",color="yellow",size=90)) %>% 
                                                                
      #visGroups(groupname = "like", shape = "icon", icon = icon("thumbs-up"),size=30) %>% 
                                                                
    addFontAwesome() %>%
     
    visOptions(highlightNearest = TRUE, selectedBy = "group") %>%
    visEdges(arrows = "middle")
  })
  
}

#### UI ###############################################################################
#################################UI WIDGETS ##########################################

ui <- shinyUI(fluidPage(
  div(style="height:2000px;",
  titlePanel("Comments Intelligence "),
      sidebarLayout(
        sidebarPanel(width = 2,
                     
          selectInput("quarter", 
                      label = "Select a period:",
                      choices = c("Quarter 1","Quarter 2",
                                  "Quarter 3","Quarter 4")), 
    
          radioButtons("wishlike", "Select Wish Or Like:",
                       choices = c("Like","Wish")),
          
          selectInput("words", 
                      label = "Diagonal Network: Select A Word ",
                      choices = dput(wordss)), #dput(wordss),
          
          br(),
          
          selectInput("search", 
                      label = "Search Details: Select A Word",
                      choices = NULL), #dput(wordss$a),
                      #selected = wordss[1]),
          dateRangeInput("daterange", "Date range: (yyyy-mm-dd)",
                         start  = min(dfSearch$Date),
                         end    = max(dfSearch$Date),
                         min    = min(dfSearch$Date),
                         max    = max(dfSearch$Date),
                         format = "yyyy/mm/dd",
                         separator = " - "),
          br(),
          
          sliderInput("max", "WordCloud: Select number of words", 50, min = 30,
                      max = 100, step = 10),
          
          br(),
          selectInput("levels", 
                      label = "Network Graph: Select A Depth Level",
                      choices = c("Level 1","Level 2", "Level 3"),
                      selected= "Level 1"),
          br()
          
        ),
       
################################################################################################
        mainPanel(
          tabsetPanel(
            tabPanel("Diagonal Network", diagonalNetworkOutput("diag")),
            tabPanel("Search Details",tableOutput("search")),
            tabPanel("Wordcloud",plotOutput("wordcloud", height = "350px"),plotOutput("wordplot", height = "400px",
                                                                                      width="100%")),
            tabPanel("Network Graph",visNetworkOutput("network",height = "750px"))
            
                    )
                 )
             ))
          ))

#### Run ####
shinyApp(ui = ui, server = server)
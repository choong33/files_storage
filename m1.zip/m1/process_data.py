import pandas as pd
import numpy as np
import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import json
from streamlit_echarts import st_echarts
from streamlit_echarts import JsCode
#filepath = 'D:/Users/I008328/Model Dashboard/files/'
filepath = 'data/'

@st.cache
def load_df():
    filepath = 'data/'
    df5 = pd.read_csv(filepath + 'score_20210521.csv').set_index('Unnamed: 0')
    df6 = pd.read_csv(filepath + 'score_20210609.csv').set_index('Unnamed: 0')
    df7 = pd.read_csv(filepath + 'score_20210709.csv').set_index('Unnamed: 0')
    df8 = pd.read_csv(filepath + 'score_20210808.csv').set_index('Unnamed: 0')
    df9 = pd.read_csv(filepath + 'score_20210913.csv').set_index('Unnamed: 0')
    df10 = pd.read_csv(filepath + 'score_20211011.csv').set_index('Unnamed: 0')
    df11 = pd.read_csv(filepath + 'score_20211110.csv').set_index('Unnamed: 0')
    df12 = pd.read_csv(filepath + 'score_20211209.csv').set_index('Unnamed: 0')
    df13 = pd.read_csv(filepath + 'score_20220110.csv').set_index('Unnamed: 0')
    df14 = pd.read_csv(filepath + 'score_20220210.csv').set_index('Unnamed: 0')
    df15 = pd.read_csv(filepath + 'score_20220310.csv').set_index('Unnamed: 0')
    df16 = pd.read_csv(filepath + 'score_20220411.csv').set_index('Unnamed: 0')
    df = [df5,df6,df7,df8,df9,df10,df11,df12,df13,df14,df15,df16]
    #print(df)

    return df

#@st.cache
def score_plot(auc,cap,ks,mod):
    months = ['May 21','Jun 21','Jul 21','Aug 21','Sep 21','Oct 21','Nov 21','Dec 21','Jan 22','Feb 22','Mar 22','Apr 22']
    fig = go.Figure()

    fig.add_trace(
    go.Scatter(
        x=months,
        y=auc,name="AUC",fill='tozeroy',opacity=0.8,
        text = list(auc), textposition="bottom center",
        mode='lines+markers+text',
        ))

    fig.add_trace(
    go.Scatter(
        x=months,
        y=cap,name="CAP",opacity=0.8, #fill='tozeroy',fillcolor='white',
        text = cap, textposition="bottom center",
        mode='lines+markers+text'
        ))


    fig.add_trace(
    go.Scatter(
        x=months,
        y=ks,name="KS",fill='tozeroy',opacity=0.8,
        text = ks, textposition="bottom center",
        mode='lines+markers+text'
        ))

# Add figure title
    fig.update_yaxes(range=[0.4, 1.0])
    fig.update_layout(
    title_text=f"{mod} - Monthly Performance Trend (2021-2022)",
    plot_bgcolor = 'rgb(255, 240, 179)',
    width=800,
    height=450,
    )

    #fig.show()
    
    return fig

def trend_plot(auc1,cap1,ks1,mod,auc2,cap2,ks2):
    months = ['May 21','Jun 21','Jul 21','Aug 21','Sep 21','Oct 21','Nov 21','Dec 21','Jan 22','Feb 22','Mar 22','Apr 22']
    fig = go.Figure()

    fig.add_trace(
    go.Scatter(
        x=months,
        y=auc1,name="AUC",fill='tozeroy',opacity=0.8,
        text = auc1, textposition="bottom center",
        mode='lines+markers+text',
        ))

    fig.add_trace(
    go.Scatter(
        x=months,
        y=cap1,name="CAP",opacity=0.8, #fill='tozeroy',fillcolor='white',
        text = cap1, textposition="bottom center",
        mode='lines+markers+text'
        ))


    fig.add_trace(
    go.Scatter(
        x=months,
        y=ks1,name="KS",fill='tozeroy',opacity=0.8,
        text = ks1, textposition="bottom center",
        mode='lines+markers+text'
        ))

# Add figure title
    #fig.update_yaxes(range=[0, 0.4])
    fig.update_layout(yaxis_title="Percentage",
    title_text=f"{mod} - Monthly Performance Changes (2021) - From  AUC:{auc2},   CAP:{cap2},   KS:{ks2}",
    plot_bgcolor = 'rgb(255, 240, 179)',
    width=800,
    height=450,
    )

    #fig.show()
    
    return fig
#@st.cache
def score_performance(mod,df):
    auc = []
    cap = []
    ks = []
    for i in df:
        
        a = i.loc[mod,'AUC']
        c = i.loc[mod,'CAP']
        k = i.loc[mod,'KS']
        auc.append(a)
        cap.append(c)
        ks.append(k)
    return (auc,cap,ks)

def score(mod,df):
    auc = []
    cap = []
    ks = []
    for i in df:
        
        a = i.loc[mod,'AUC']
        c = i.loc[mod,'CAP']
        k = i.loc[mod,'KS']
        auc.append(a)
        cap.append(c)
        ks.append(k)
    return (auc,cap,ks)

def model_plot():
    models = ['NB','AEG','ALC','ALL','ALMR','ALS','APA','LADY','POST','TPA','THS','TWS']
    for mod in models:
        auc,cap,ks = score(mod,df)
        plots = score_plot(auc,cap,ks)

    return plots

def auc_chg(mod,df):
    mod10 = []
    mod20 = []
    for i in df:
        
        m10 = i[mod][0]
        m20 = i[mod][1]
        #print(m10)
        #print(m20)
        mod10.append(m10)
        mod20.append(m20)
    return (mod10, mod20)

# Lift curve Trend
@st.cache
def load_lift_df():
    df5 = pd.read_csv(filepath + 'lift_20210521.csv')
    df6 = pd.read_csv(filepath + 'lift_20210609.csv')
    df7 = pd.read_csv(filepath + 'lift_20210709.csv')
    df8 = pd.read_csv(filepath + 'lift_20210808.csv')
    df9 = pd.read_csv(filepath + 'lift_20210913.csv')
    df10 = pd.read_csv(filepath + 'lift_20211011.csv')
    df11 = pd.read_csv(filepath + 'lift_20211110.csv')
    df12 = pd.read_csv(filepath + 'lift_20211209.csv')
    df13 = pd.read_csv(filepath + 'lift_20220110.csv')
    df14 = pd.read_csv(filepath + 'lift_20220210.csv')
    df15 = pd.read_csv(filepath + 'lift_20220310.csv')
    df16 = pd.read_csv(filepath + 'lift_20220411.csv')
    df_lift = [df5,df6,df7,df8,df9,df10,df11,df12,df13,df14,df15,df16]

    return df_lift

def lift_chg(mod,df):
    mod10 = []
    mod20 = []
    for i in df:
        
        m10 = i[mod][0]
        m20 = i[mod][1]
        #print(m10)
        #print(m20)
        mod10.append(m10)
        mod20.append(m20)
    return (mod10, mod20)

def lift_plot(lift10,lift20,mod,a,b):
    months = ['May 21','Jun 21','Jul 21','Aug 21','Sep 21','Oct 21','Nov 21','Dec 21','Jan 22','Feb 22','Mar 22','Apr 22']
    fig = make_subplots(rows=1, cols=2,subplot_titles=("Lift at 10%", "Lift at 20%"),
                    horizontal_spacing=0.1,vertical_spacing=0.02,
                    specs=[[{"secondary_y": True}, {"secondary_y": True}]])

# fig = make_subplots(rows=2, cols=2,
#                     specs=[[{"secondary_y": True}, {"secondary_y": True}],
#                            [{"secondary_y": True}, {"secondary_y": True}]])


# Top left
    fig.add_trace(
        go.Bar(x=months, y=a, name="Lift at 10%",opacity=0.8),
        row=1, col=1, secondary_y=False)

    fig.add_trace(
        go.Scatter(x=months[1:], y=lift10, name="% Changes",text = lift10,textposition="bottom center",mode='lines+markers+text'),
        row=1, col=1, secondary_y=True,
    )

# Top right
    fig.add_trace(
        go.Bar(x=months, y=b, name="Lift at 20%",opacity=0.8),
        row=1, col=2, secondary_y=False,
    )

    fig.add_trace(
        go.Scatter(x=months[1:], y=lift20, name="% Changes",text = lift20,textposition="bottom center",mode='lines+markers+text'),
        row=1, col=2, secondary_y=True,
    )

# Add figure title
    fig.update_layout(
        title_text=f"{mod} - Monthly Lift Trend",
        width=950,
        height=400,
    )


    #fig.show()
    return fig

def render_stacked_area_chart():
    options = {
        "title": {"text": "堆叠区域图"},
        "tooltip": {
            "trigger": "axis",
            "axisPointer": {"type": "cross", "label": {"backgroundColor": "#6a7985"}},
        },
        "legend": {"data": ["邮件营销", "联盟广告", "视频广告", "直接访问", "搜索引擎"]},
        "toolbox": {"feature": {"saveAsImage": {}}},
        "grid": {"left": "3%", "right": "4%", "bottom": "3%", "containLabel": True},
        "xAxis": [
            {
                "type": "category",
                "boundaryGap": False,
                "data": ["周一", "周二", "周三", "周四", "周五", "周六", "周日"],
            }
        ],
        "yAxis": [{"type": "value"}],
        "series": [
            {
                "name": "邮件营销",
                "type": "line",
                "stack": "总量",
                "areaStyle": {},
                "emphasis": {"focus": "series"},
                "data": [120, 132, 101, 134, 90, 230, 210],
            },
            {
                "name": "联盟广告",
                "type": "line",
                "stack": "总量",
                "areaStyle": {},
                "emphasis": {"focus": "series"},
                "data": [220, 182, 191, 234, 290, 330, 310],
            },
            {
                "name": "视频广告",
                "type": "line",
                "stack": "总量",
                "areaStyle": {},
                "emphasis": {"focus": "series"},
                "data": [150, 232, 201, 154, 190, 330, 410],
            },
            {
                "name": "直接访问",
                "type": "line",
                "stack": "总量",
                "label": {"show": True, "position": "top"},
                "areaStyle": {},
                "emphasis": {"focus": "series"},
                "data": [320, 332, 301, 334, 390, 330, 320],
            },
            {
                "name": "搜索引擎",
                "type": "line",
                "stack": "总量",
                "label": {"show": True, "position": "top"},
                "areaStyle": {},
                "emphasis": {"focus": "series"},
                "data": [820, 932, 901, 934, 1290, 1330, 1320],
            },
        ],
    }
    return st_echarts(options=options, height="400px")
#https://echarts.apache.org/examples/en/index.html
#https://discuss.streamlit.io/t/a-dashboard-based-on-streamlit-and-echarts/15142
#https://plotly.com/python/bar-charts/ - 4.14.3

import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
import codecs
from PIL import Image
import streamlit.components.v1 as components
from streamlit_echarts import st_echarts
import datetime
from process_data import load_df, score_performance, score_plot, load_lift_df, lift_plot, lift_chg, render_stacked_area_chart, trend_plot
from pyecharts.charts import Bar
from pyecharts import options as opts

st.set_page_config(page_title="Monitor Dashboard",layout='wide')

def main():
    html_temp1 = """<div style="background-color:#ff0055;padding:5px">
                            		<h1 style="color:white;text-align:center;">Model Monitoring Dashboard</h1>
                            		</div>
                            		</div>
                            		</br>"""
    st.markdown(html_temp1, unsafe_allow_html=True)

    menu = ["Summary Dashboard","Model Performance (Current)","Model Performance Trend","SHAP Plots", "Data And Target Drift"]
    choice = st.sidebar.selectbox("Menu", menu, 0)
    # for hide menu
    hide_streamlit_style = """
                    <style>
                    #MainMenu {visibility: hidden;}
                    footer {visibility: hidden;}
                    </style>
                    """
    model_type = ['nb','all','almr','als','alc','aeg','tpa','apa','post','tws','ths','lady']
    models = st.sidebar.multiselect('Select Models', model_type)

    date1 = st.sidebar.date_input("Test date picker:", [datetime.date(2021, 7, 6)])

    st.markdown(hide_streamlit_style, unsafe_allow_html=True)

    st.sidebar.title("About")
    st.sidebar.info(" **Dashboard** - Please give feedback on adding features that you think are useful")

    st.sidebar.markdown(
        """ Developed by DS Team    
        """)
    if choice == "Model Performance (Current)": 
        # color codes  ff1a75  6D7B8D
        html_temp2 = """<div style="background-color:#white;padding:5px;background-image: linear-gradient(whitesmoke , white)">
                                        		<h3 style="color:black;text-align:center;">Model Performance</h3>
                                        		</div>
                                        		<div>
                                        		</br>"""
        st.markdown(html_temp2, unsafe_allow_html=True)

        # CHANGE EVERY MONTH
        #perf_file = open('D:/propensity_models_scheduled/evaluation-repo/propensity_evaluation_20211011.html','r',encoding='utf-8')
        perf_file = open('data/propensity_evaluation_20220110.html','r',encoding='utf-8')
        page = perf_file.read()
        
        col1, col2, col3 = st.columns([1,6,1])
        with col1:
            st.write("")
        with col2:
            components.html(page,width=1000, height=700,scrolling=True)
        with col3:
            st.write("")
        
    elif choice == "Model Performance Trend": 
        # color codes  ff1a75  6D7B8D
        html_temp2 = """<div style="background-color:#white;padding:5px;background-image: linear-gradient(whitesmoke , white)">
                                        		<h3 style="color:black;text-align:center;">Model Lift And Performance Monthly Trend</h3>
                                        		</div>
                                        		<div>
                                        		</br>"""
        st.markdown(html_temp2, unsafe_allow_html=True)
        expander_bar = st.expander("ALERT IF:")
        expander_bar.markdown("""
                              * **Case 1:**  if AUROC decay >0.1 or AUROC < 0.75 - If thers is a decay of more than 10% in AUC or the current AUC is less than 0.75
                              * **Case 2:**  if KS decay > 0.1 or KS <0.4 - Similartly a decay in KS more than 10% or current KS is less than 0.4 
                              * **Case 3:**  if (Lift10 decay > 15% or Lift10 < 3) AND (Lift20 decay < 12% or Lift20 < 2) 	
                              """)
        model_type_month = ['NB','ALL','ALMR','ALS','ALC','AEG','TPA','APA','POST','TWS','THS','LADY']
        models = st.multiselect('Select Models', model_type_month,model_type_month)
        
        _,tc1,tc3,tc2,_= st.columns([1,1,1,1,1])
        performance = tc1.button('Models Performance Trend')

        with tc2:
            
            lift = st.button('     Models Lift Trend     ')

        with tc3:
            
            trend_chg = st.button('Models Performance Changes')

        if performance:
            df = load_df()
            for mod in models:
                auc,cap,ks = score_performance(mod,df)
                fig = score_plot(auc,cap,ks,mod)

                fig.update_layout(width=300,height=500)

                st.plotly_chart(fig,use_container_width=True)

        elif lift:
            df = load_lift_df()

            for mod in models:
                lift10 = []
                lift20 = []
                a, b = lift_chg(mod,df)
                for i in range(len(a)-1):
                    #l10 = (a[i+1]-a[i])/a[i]
                    #l20 = (b[i+1]-b[i])/b[i]
                    l10 = (a[i+1]-a[0])/a[0]
                    l20 = (b[i+1]-b[0])/b[0]
                    lift10.append(l10)
                    lift20.append(l20)
                
                lift10 = [round(x*100,1) for x in lift10]
                lift20 = [round(x*100,1) for x in lift20]
                #print(lift10)
    
                fig = lift_plot(lift10,lift20,mod,a,b)
                fig.update_layout(width=400,height=500)
                st.plotly_chart(fig,use_container_width=True)

        elif trend_chg:
            df = load_df()
            for mod in models:
                auc,cap,ks = score_performance(mod,df)
            
                auc1 = []
                cap1 = []
                ks1 = []
                for i in range(len(auc)-1):
                    #l10 = (a[i+1]-a[i])/a[i]
                    #l20 = (b[i+1]-b[i])/b[i]
                    a1 = (auc[i+1]-auc[0])/auc[0]
                    c1 = (cap[i+1]-cap[0])/cap[0]
                    k1 = (ks[i+1]-ks[0])/ks[0]
                    auc1.append(a1)
                    cap1.append(c1)
                    ks1.append(k1)

                auc1 = [round(x*100,1) for x in auc1]
                cap1 = [round(x*100,1) for x in cap1]
                ks1 = [round(x*100,1) for x in ks1]
                auc2 = auc[0]
                cap2 = cap[0]
                ks2 = ks[0]
                fig = trend_plot(auc1,cap1,ks1,mod,auc2,cap2,ks2)

                fig.update_layout(width=300,height=500)

                st.plotly_chart(fig,use_container_width=True)

    elif choice == "SHAP Plots": # JS/Joe
        html_temp3 = """
                        		<div style="background-color:#white;padding:5px;background-image: linear-gradient(whitesmoke , white)">
                        		<h3 style="color:black;text-align:center;">SHAP PLOTS</h3>
                        		</div>
                        		<br></br>"""

        st.markdown(html_temp3, unsafe_allow_html=True)
        
        model_type_shap = ['nb','all','almr','als','alc','aeg','tpa','apa','post','tws','ths','lady']
        models = st.selectbox('Select Model', model_type_shap)
        
        col1, col2= st.columns([1,1])
        
        with col1:
            st.write(" **Model Beeswarm Plot**")
            beeswarm = Image.open(f'./data/{models}_beeswarm.png')
            st.image(beeswarm)
            #st.image('D:/Users/I008328/Model Dashboard/files/' + models + '_' +'.png')
        with col2:
            st.write(" **Model Summary Plot**")
            sum_plot = Image.open(f'./data/{models}_summary_plot.png')
            st.image(sum_plot)

        st.markdown("""---""")

        col3, col4= st.columns([1,1])

        with col3:
            st.write(" **Model Waterfall Positive Plot**")
            pos_plot = Image.open(f'./data/{models}_waterfall_highest_proba.png')
            st.image(pos_plot)
            #st.image('D:/Users/I008328/Model Dashboard/files/' + models + '_' +'.png')
        with col4:
            st.write(" **Model Waterfall Negative Plot**")
            neg_plot = Image.open(f'./data/{models}_waterfall_lowest_proba.png')
            st.image(neg_plot)
        
    elif choice == "Data And Target Drift": # Hui San
        html_temp4 = """
        <div style="background-color:#white;padding:5px;background-image: linear-gradient(whitesmoke , white)">
        <h3 style="color:black;text-align:center;">Data And Target Drift</h3>
        </div>
        <br></br>"""

        st.markdown(html_temp4, unsafe_allow_html=True)
        
        model_type_month = ['NB','ALL','ALMR','ALS','ALC','AEG','TPA','APA','POST','TWS','THS','LADY']
        models = st.selectbox('Select Models', model_type_month)

        perf_file = open('./data/pdt_drift_oft_' + models + '.html', 'r',encoding='utf-8')
        page = perf_file.read()
        
        col1, col2, col3 = st.columns([1,10,1])
        with col1:
            st.write("")
        with col2:
            #components.html(page,width=1200, height=7000)
            components.html(page,width=1000, height=800,scrolling=True)
        with col3:
            st.write("")
            
    elif choice == "Summary Dashboard":
        html_temp5 = """
        <div style="background-color:#white;padding:5px;background-image: linear-gradient(whitesmoke , white)">
        <h3 style="color:black;text-align:center;">Summary Of Performance Metrics</h3>
        </div>
        <br></br>"""

        st.markdown(html_temp5, unsafe_allow_html=True)
        
        # CHANGE EVERY MONTH
        #score = pd.read_csv('D:/Users/I008328/Model Dashboard/files/score_20220310.csv').set_index('Unnamed: 0')
        score = pd.read_csv('./data/score_20220411.csv').set_index('Unnamed: 0')
        kpi1, kpi2, kpi3 = st.columns(3)

        with kpi1:
            
            text1 = 'AUC'
            #st.markdown(f"""<div class="circle">Call Us!<span class="info">123.456.7890</span></div>""", unsafe_allow_html=True)
            st.markdown(f"<h1 style='text-align: left;font-weight: bold; color: black;'>{text1}</h1>", unsafe_allow_html=True)
            auc = score.AUC.max() *100
            
            option = {
                "tooltip": {
                            "formatter": '{a} <br/>{b} : {c}%'
                        },
                    'series': [{
                        'type': 'gauge',
                        'progress': {
                         'show': 'true',
                        'width': 20
                        },
                        'axisLine': {
                        'lineStyle': {
                        'width': 18
                        }
                    },
                    'axisTick': {
                        'show': 'false'
                    },
                    'splitLine': {
                        'length': 10,
                        'lineStyle': {
                        'width': 2,
                        'color': '#999'
                        }
                    },
                    'axisLabel': {
                        'distance': 25,
                        'color': '#999',
                        'fontSize': 15
                    },
                    'anchor': {
                        'show': 'true',
                        'showAbove': 'true',
                        'size': 20,
                        'itemStyle': {
                        'borderWidth': 10
                        }
                    },
                    'title': {
                        'show': 'false'
                    },
                    'detail': {
                        'valueAnimation': 'true',
                        'fontSize': 38,
                        "width": '60%',
                        "lineHeight": 20,
                        "height": 20,
                        "color":"#ff0000",
                        "borderRadius": 188,
                        'offsetCenter': [0, '70%']
                    },
                    'data': [{
                        'value': auc
                    }]
                }]
            };

            st_echarts(options=option, key="1")


        with kpi2:
            text2 = 'K-S'
            st.markdown(f"<h1 style='text-align: left;font-weight: bold; color: black;'>{text2}</h1>", unsafe_allow_html=True)
            ks = score.KS.max() * 100
            
            option = {
                "tooltip": {
                            "formatter": '{a} <br/>{b} : {c}%'
                        },
                    'series': [{
                        'type': 'gauge',
                        'progress': {
                         'show': 'true',
                        'width': 20
                        },
                        'axisLine': {
                        'lineStyle': {
                        'width': 18
                        }
                    },
                    'axisTick': {
                        'show': 'false'
                    },
                    'splitLine': {
                        'length': 10,
                        'lineStyle': {
                        'width': 2,
                        'color': '#999'
                        }
                    },
                    'axisLabel': {
                        'distance': 25,
                        'color': '#999',
                        'fontSize': 15
                    },
                    'anchor': {
                        'show': 'true',
                        'showAbove': 'true',
                        'size': 20,
                        'itemStyle': {
                        'borderWidth': 10
                        }
                    },
                    'title': {
                        'show': 'false'
                    },
                    'detail': {
                        'valueAnimation': 'true',
                        'fontSize': 38,
                        "width": '60%',
                        "lineHeight": 20,
                        "height": 20,
                        "color":"#ff0000",
                        "borderRadius": 188,
                        'offsetCenter': [0, '70%']
                    },
                    'data': [{
                        'value': ks
                    }]
                }]
            };

            st_echarts(options=option, key="2")


        with kpi3:
            text3 = 'CAP'
            st.markdown(f"<h1 style='text-align: left;font-weight: bold; color: black;'>{text3}</h1>", unsafe_allow_html=True)
            cap = score.CAP.max() *100
            
            option = {
                "tooltip": {
                            "formatter": '{a} <br/>{b} : {c}%'
                        },
                    'series': [{
                        'type': 'gauge',
                        'progress': {
                         'show': 'true',
                        'width': 20
                        },
                        'axisLine': {
                        'lineStyle': {
                        'width': 18
                        }
                    },
                    'axisTick': {
                        'show': 'false'
                    },
                    'splitLine': {
                        'length': 10,
                        'lineStyle': {
                        'width': 2,
                        'color': '#999'
                        }
                    },
                    'axisLabel': {
                        'distance': 25,
                        'color': '#999',
                        'fontSize': 15
                    },
                    'anchor': {
                        'show': 'true',
                        'showAbove': 'true',
                        'size': 20,
                        'itemStyle': {
                        'borderWidth': 10
                        }
                    },
                    'title': {
                        'show': 'false'
                    },
                    'detail': {
                        'valueAnimation': 'true',
                        'fontSize': 38,
                        "width": '60%',
                        "lineHeight": 20,
                        "height": 20,
                        "color":"#ff0000",
                        "borderRadius": 188,
                        'offsetCenter': [0, '70%']
                        #'formatter': 'value'
                    },
                    'data': [{
                        'value':cap,
                        

                    }]
                }]
            };

            st_echarts(options=option, key="3")

        st.markdown("""---""")
        st.write("")
        #st.write("")
        st.write("")

        chart1, chart2 = st.columns([2,1])
        with chart1:
            
            text1 = "AUC Min-Max Trend Line"
            st.markdown(f"<h2 style='text-align: center; color: black;'>{text1}</h2>", unsafe_allow_html=True)
    
            df = load_df()
            # ADD 1 MONTH - MONTHLY
            maxa= pd.Series([df[0].AUC.max(),df[1].AUC.max(),df[2].AUC.max(),df[3].AUC.max(),df[4].AUC.max(),df[5].AUC.max(),df[6].AUC.max(),df[7].AUC.max(),
            df[8].AUC.max(),df[9].AUC.max(),df[10].AUC.max(),df[11].AUC.max()],name='Max')
            mina = pd.Series([df[0].AUC.min(),df[1].AUC.min(),df[2].AUC.min(),df[3].AUC.min(),df[4].AUC.min(),df[5].AUC.min(),df[6].AUC.min(),df[7].AUC.min(),
            df[8].AUC.min(),df[9].AUC.min(),df[10].AUC.min(),df[11].AUC.min()],name='Min')
            max_model = [str(df[0].AUC.idxmax()),str(df[1].AUC.idxmax()),str(df[2].AUC.idxmax()),str(df[3].AUC.idxmax()),
                         str(df[4].AUC.idxmax()),str(df[5].AUC.idxmax()),str(df[6].AUC.idxmax()),str(df[7].AUC.idxmax()),str(df[8].AUC.idxmax()),
                         str(df[9].AUC.idxmax()),str(df[10].AUC.idxmax()),str(df[11].AUC.idxmax())]
            min_model = [str(df[0].AUC.idxmin()),str(df[1].AUC.idxmin()),str(df[2].AUC.idxmin()),str(df[3].AUC.idxmin()),
                         str(df[4].AUC.idxmin()),str(df[5].AUC.idxmin()),str(df[6].AUC.idxmin()),str(df[7].AUC.idxmin()),str(df[8].AUC.idxmin()),
                         str(df[9].AUC.idxmin()),str(df[10].AUC.idxmin()),str(df[11].AUC.idxmin())]
            #print(max_model[0:2])
            monthly_auc = pd.concat([maxa,mina],axis=1)
            monthly_auc.index = ['May 21','Jun 21','Jul 21','Aug 21','Sep 21','Oct 21','Nov 21','Dec 21','Jan 22','Feb 22','Mar 22','Apr 22']
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=['May 21','Jun 21','Jul 21','Aug 21','Sep 21','Oct 21','Nov 21','Dec 21','Jan 22','Feb 22','Mar 22','Apr 22'], y=maxa, name="Max AUC", fill='tozeroy',
                          text = maxa, textposition="top center",mode='lines+markers+text')) # fill down to xaxis
            fig.add_trace(go.Scatter(x=['May 21','Jun 21','Jul 21','Aug 21','Sep 21','Oct 21','Nov 21','Dec 21','Jan 22','Feb 22','Mar 22','Apr 22'], y=mina, name="Min AUC", #fill='tozeroy',
                          text = mina, textposition="bottom center",mode='lines+markers+text')) # fill to trace0 y
            
            fig.update_yaxes(range=[0.6, 1.0])

            j=0
            for i in max_model:
                
                fig.add_annotation(
                               text=i,
                               xanchor='auto',showarrow=True,
                               x=j,
                               y=maxa[j])
                j +=1
            
            j=0
            for i in min_model:
                
                fig.add_annotation(
                               text=i,
                               xanchor='auto',showarrow=True,
                               x=j,
                               y=mina[j])
                j +=1
                                 
            fig.update_layout(plot_bgcolor = 'rgb(255, 240, 179)',
            #title_text=f"{mod} - Monthly Performance Trend (2021)",
            width=520,
            height=500)

            st.plotly_chart(fig,use_container_width=True)

        with chart2: # 

            text2 = "Models Lift Changes @ 10 Percent"
            st.markdown(f"<h2 style='text-align: center; color:black;'>{text2}</h2>", unsafe_allow_html=True)
            #st.markdown(" ", unsafe_allow_html=True)
            df_lift = load_lift_df()

            df = load_lift_df()
            models = ['NB','AEG','ALC','ALL','ALMR','ALS','APA','LADY','POST','TPA','THS','TWS']
            lift_decay = pd.DataFrame()
            for mod in models:
                lift10 = []
                lift20 = []
                a, b = lift_chg(mod,df)
                for i in range(len(a)-1):
                    #l10 = (a[i+1]-a[i])/a[i]
                    #l20 = (b[i+1]-b[i])/b[i]
                    l10 = (a[i+1]-a[0])/a[0]
                    l20 = (b[i+1]-b[0])/b[0]
                    lift10.append(l10)
                    lift20.append(l20)
                
                lift10 = [round(x*100,1) for x in lift10]
                lift20 = [round(x*100,1) for x in lift20]
                lift1 = pd.Series(lift10,name=mod)
                lift_decay = pd.concat([lift_decay,lift1],axis=1)

##########################################################################################
            # df_sort = round(df_lift[5].loc[0].sort_values(ascending =False),2)
            # names = [df_sort.index[0], df_sort.index[1], df_sort.index[2],df_sort.index[3],df_sort.index[4]]
            # values = [df_sort[0], df_sort[1], df_sort[2],df_sort[3],df_sort[4]]

            df_sort = round(lift_decay.iloc[-1].sort_values(),2)
            names = [df_sort.index[0], df_sort.index[1], df_sort.index[2],df_sort.index[3],df_sort.index[4]]
            values = [df_sort[0], df_sort[1], df_sort[2],df_sort[3],df_sort[4]]
            
            # PIE CHART
            # option = {
            #         "legend": {
            #             "top": 'top'
            #         },
            #         "toolbox": {
            #             "show": "true",
            #             "feature": {
            #                 "mark": {"show": "true"},
            #                 "dataView": {"show": "true", "readOnly": "false"},
            #                 "restore": {"show": "true"},
            
            #             }
            #         },
            #         "series": [
            #             {
            #                 "name": 'Model Lift',
            #                 "type": 'pie',
            #                 "radius": ["30", "120"],
            #                 "center": ['50%', '60%'],
            #                 "roseType": 'area',
            #                 "itemStyle": {
            #     "borderRadius": "8"
            #                 },
            #                 "data": [
            #                     {"value": values[0], "name": names[0]},
            #                     {"value": values[1], "name": names[1]},
            #                     {"value": values[2], "name": names[2]},
            #                     {"value": values[3], "name": names[3]},
            #                     {"value": values[4], "name": names[4]}
            #                 ]
            #             }
            #         ],
            #         "tooltip": {
            #                         "show": "true"
            #                     },
            #         "label": {
            #             "show":"true"
            #         },
            #             };
            # st_echarts(options=option, key="4")
            
            # 
            fig = go.Figure()

            fig.add_trace(go.Bar(x = df_sort,
                    y = df_sort.index, #models,
                    orientation = "h",
                    text=df_sort,
                    textposition='auto',
                    name='Lift'
                    ))

            fig.update_layout(plot_bgcolor = "white",
                    font = dict(color = "#909497"),
                    width=400,
                    height=510,
                    #mode='bars+markers+text',
                    xaxis = dict(title = "Percentage (%)", linecolor = "#909497"), #tick prefix is the html code for Rupee
                    #yaxis = dict(title = "Product Category", tickformat = ",", linecolor = "#909497",
                    #            categoryorder = "array", categoryarray = CATEGORY_ORDER)) #apply our custom category order
                    )

            # j=0
            # for i in df_sort.index:
                
            #     fig.add_annotation(
            #                    text=str(df_sort[i]),
            #                    xanchor='auto',#showarrow=True,
            #                    x=df_sort[j],
            #                    y=i)
            #     j +=1
            st.plotly_chart(fig,use_container_width=True)

        st.markdown("""---""")
       
        chart3, chart4, chart5 = st.columns([1,1,1])

        with chart3:
            
            text1 = "Models AUC"
            st.markdown(f"<h3 style='text-align: center; color: black;'>{text1}</h3>", unsafe_allow_html=True)
            
            fig = px.bar(score.AUC,height=350)
            fig.update_traces(marker_color='rgb(255, 204, 0)', marker_line_color='rgb(8,48,107)', 
                  marker_line_width=1.5, textposition='inside',opacity=0.6)
            fig.update_layout(
                    #title="CAP",
                    #mode='lines+markers+text',
                    xaxis_title="Model",
                    yaxis_title="AUC",
                    legend_title="AUC",
                    font=dict(
                    family="Courier New, monospace",
                    size=12,
                    color="Black"))
            #fig2.update_xaxes(title = 'Model', x)
            st.plotly_chart(fig,use_container_width=True)

        with chart4:
            
            text1 = "Models K-S"
            st.markdown(f"<h3 style='text-align: center; color: black;'>{text1}</h3>", unsafe_allow_html=True)
            
            fig = px.bar(score.KS,height=350)
            fig.update_traces(marker_color='rgb(153, 153, 77)', marker_line_color='rgb(8,48,107)',
                  marker_line_width=1.5, opacity=0.6)
            fig.update_layout(
                    #title="CAP",
                    xaxis_title="Model",
                    yaxis_title="K-S",
                    legend_title="K-S",
                    font=dict(
                    family="Courier New, monospace",
                    size=12,
                    color="Black"))
 
            #fig2.update_xaxes(title = 'Model', x)
            st.plotly_chart(fig,use_container_width=True)

        with chart5:
            
            text1 = "Models CAP"
            st.markdown(f"<h3 style='text-align: center; color: black;'>{text1}</h3>", unsafe_allow_html=True)
            # chart_data5 = pd.DataFrame(np.random.uniform(low=0.6, high=0.8, size=(1,12)),columns=['nb','all','almr','als','alc','aeg',
            # 'tpa','apa','post','tws','ths','lady'])
            
            fig = px.bar(score.CAP,height=350)
            fig.update_traces(marker_color='rgb(255, 102, 102)', marker_line_color='rgb(8,48,107)',
                  marker_line_width=1.5, opacity=0.6)
            fig.update_layout(
                    #title="CAP",
                    xaxis_title="Model",
                    yaxis_title="CAP",
                    legend_title="CAP",
                    font=dict(
                    family="Courier New, monospace",
                    size=12,
                    color="Black"))
            

            #fig2.update_xaxes(title = 'Model', x)
            st.plotly_chart(fig,use_container_width=True)

        #render_stacked_area_chart()

        # c = (Bar()
        #          .add_xaxis(list(score.index))
        #          .add_yaxis('CAP', list(score.CAP), is_stack=True)
        #          #.add_xaxis(list(score.index),is_stack=True)
        #          .add_yaxis('AUC', list(score.AUC), is_stack=True)

        #          .set_global_opts(title_opts=opts.TitleOpts(title="Models CAP", subtitle="Latest Month"),
        #              toolbox_opts=opts.ToolboxOpts())
        #         .render_embed() # generate a local HTML file
        #         )
        # components.html(c, width=1000, height=500)

    else:
        pass
    
if __name__ == "__main__":
    main()